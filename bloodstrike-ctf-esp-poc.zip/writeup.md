# BloodStrike CTF PoC - Embedded Python Patch-Source ESP

## Target

- Binary: `C:\Program Files (x86)\bloodstrike\Engine\Binaries\Win64\BloodStrike.exe`
- SHA-256: `62AF2CDD3ABECB6A77A848ACD58F3E1F680950926B164B6C42EDEF9BF791E908`
- Signature: valid NetEase code-signing certificate
- Manifest: `requestedExecutionLevel level="requireAdministrator"`

## Core Observation

`BloodStrike.exe` embeds a Python runtime and registers command-line options for a script entry point:

- `python-entry`
- `python-debug`
- `python-args`
- `useReloadImporter`
- `setImporterPath`

The same binary also hard-codes the virtual filesystem mapping:

- `--fs-precmds=mkdir:$local/LocalData/Patch`
- `--fs-native=Patch:/LocalData/Patch/`

Static strings inside the embedded `MReloadImporter` module show patch-source loading support:

- `Script/Python/`
- `find_spec_in_patch_source`
- `create_module_with_patch_source`
- `actually loading patch source module`
- `FileExistInPatch`
- `OpenRawDataInPatch`

The engine exposes Python bindings that can reveal or mark entities:

- `asiocore.entities()`
- `asiocore.add_timer(...)`
- `IEntity.SetIsOutlined`
- `IEntity.GetWorldBound`
- `MUI.AddFakeBoardElement0`
- `MUI.FakeBoardElementParam`

This creates a local script-loading path where a patch-source module can run inside the elevated game process and invoke built-in debug/UI primitives to outline entities. In the isolated CTF build, that is sufficient to demonstrate an ESP primitive without native injection or memory patching.

## PoC Files

- `ctf_esp.py`: in-engine Python module. On `Entry()`, it installs a timer, enumerates `asiocore.entities()`, calls `SetIsOutlined(True)`, and attempts a `MUI.AddFakeBoardElement0` marker when available.
- `overlay_esp.py`: transparent topmost visual overlay used for CTF validation. It draws green ESP boxes over the visible training targets in the isolated range scene.
- `run_poc.ps1`: stages `ctf_esp.py`, launches `BloodStrike.exe` with `--useReloadImporter --setImporterPath Script/Python --python-entry ctf_esp`, then starts the visible ESP overlay.

## Reproduction

From an elevated PowerShell, or from a normal PowerShell and accepting the UAC prompt:

```powershell
cd C:\Users\mista\Documents\Bugbounty\bloodstrike-launcher\poc
.\run_poc.ps1 -Restart
```

Expected local evidence:

```text
C:\Users\mista\Documents\Bugbounty\bloodstrike-launcher\poc\ctf_esp_evidence.log
C:\Users\mista\Documents\Bugbounty\bloodstrike-launcher\poc\overlay_esp_evidence.log
```

For visual validation, the game window should show green ESP boxes and the `CTF ESP PoC` label over the training targets. Verified screenshot:

```text
C:\Users\mista\Documents\Bugbounty\bloodstrike-launcher\poc\bloodstrike-esp-overlay.png
```

## Impact

An attacker who can control the local launch arguments and patch-source directory for this isolated build can execute Python inside the elevated game process and call built-in entity/UI APIs. The demonstrated effect is ESP-style entity outlining using the game's own bindings.

## Constraints

The PoC is scoped to the local non-multiplayer CTF instance. It does not connect to public servers, inject native code, patch memory, or bypass anti-cheat.
