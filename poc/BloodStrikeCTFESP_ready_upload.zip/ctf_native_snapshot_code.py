"""State exporter for the local CTF ESP renderer.

The renderer is the native C++ process in cpp_overlay.  This module only reads
the isolated game's own entity and camera state, then writes an atomically
replaced text snapshot for the renderer to consume.
"""

import builtins as _ctf_native_builtins
import gc as _ctf_native_gc
import math as _ctf_native_math
import os as _ctf_native_os
import time as _ctf_native_time
import traceback as _ctf_native_traceback


_ctf_native_state_name = "_ctf_bloodstrike_native_esp_state"
_ctf_native_legacy_state_name = "_ctf_bloodstrike_live_esp_state"
_ctf_native_root = _ctf_native_os.path.dirname(_ctf_native_os.path.abspath(__file__))
_ctf_native_snapshot_path = _ctf_native_os.path.join(_ctf_native_root, "ctf_native_esp_state.txt")
_ctf_native_snapshot_temp_path = _ctf_native_snapshot_path + ".tmp"
_ctf_native_log_path = _ctf_native_os.path.join(_ctf_native_root, "ctf_native_esp.log")
_ctf_native_config_path = _ctf_native_os.path.join(_ctf_native_root, "ctf_native_esp_config.txt")
_ctf_native_aim_trigger_path = _ctf_native_os.path.join(_ctf_native_root, "ctf_native_aim_trigger.txt")
_ctf_native_default_max_distance = 800.0
_ctf_native_aim_bones = (
    "biped Head",
    "biped Neck",
    "biped Spine2",
    "biped Spine1",
    "biped Spine",
    "biped Pelvis",
)
_ctf_native_vk_rbutton = 0x02
_ctf_native_user32 = None
# The host calls the timer close to 60 Hz.  A 1/60 throttle can reject callbacks
# that arrive a fraction early and halve the effective rate, so keep this below
# one host tick while leaving visibility checks independently cached.
_ctf_native_snapshot_interval = 1.0 / 240.0


def _ctf_native_log(message):
    try:
        with open(_ctf_native_log_path, "a", encoding="utf-8") as _ctf_native_handle:
            _ctf_native_handle.write("{:.3f} {}\n".format(_ctf_native_time.time(), message))
    except Exception:
        pass


def _ctf_native_call(obj, name, *args):
    try:
        return getattr(obj, name)(*args)
    except Exception:
        return None


def _ctf_native_vec3(value):
    if value is None:
        return None
    try:
        return (float(value.x), float(value.y), float(value.z))
    except Exception:
        pass
    try:
        return (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        return None


def _ctf_native_make_vec3_like(template, point):
    try:
        _ctf_native_value = template.clone()
        _ctf_native_value.x = float(point[0])
        _ctf_native_value.y = float(point[1])
        _ctf_native_value.z = float(point[2])
        return _ctf_native_value
    except Exception:
        pass
    try:
        import MType as _ctf_native_mtype
        _ctf_native_value = _ctf_native_mtype.Vector3()
        _ctf_native_value.x = float(point[0])
        _ctf_native_value.y = float(point[1])
        _ctf_native_value.z = float(point[2])
        return _ctf_native_value
    except Exception:
        return None


def _ctf_native_point_in_bounds(point, low, high, padding=0.45):
    if point is None or low is None or high is None:
        return True
    try:
        return (
            low[0] - padding <= point[0] <= high[0] + padding and
            low[1] - padding <= point[1] <= high[1] + padding and
            low[2] - padding <= point[2] <= high[2] + padding
        )
    except Exception:
        return False


def _ctf_native_ensure_aim_bones(state, key, model):
    _ctf_native_models = state.setdefault("aim_bone_models", {})
    _ctf_native_model_id = id(model)
    if _ctf_native_models.get(key) == _ctf_native_model_id:
        return
    for _ctf_native_bone in _ctf_native_aim_bones:
        _ctf_native_call(model, "CreateSpecifyBone", _ctf_native_bone)
    _ctf_native_models[key] = _ctf_native_model_id


def _ctf_native_upper_body_fallback_points(camera_pos, low, high):
    if low is None or high is None:
        return ()
    try:
        _ctf_native_height = float(high[1] - low[1])
        if not _ctf_native_math.isfinite(_ctf_native_height) or _ctf_native_height <= 0.25:
            return ()
        _ctf_native_x = (low[0] + high[0]) * 0.5
        _ctf_native_z = (low[2] + high[2]) * 0.5
        _ctf_native_top_margin = min(0.22, max(0.08, _ctf_native_height * 0.12))
        _ctf_native_candidates = (
            (_ctf_native_x, high[1] - _ctf_native_top_margin, _ctf_native_z),
            (_ctf_native_x, low[1] + _ctf_native_height * 0.72, _ctf_native_z),
            (_ctf_native_x, low[1] + _ctf_native_height * 0.58, _ctf_native_z),
        )
        _ctf_native_result = []
        for _ctf_native_point in _ctf_native_candidates:
            _ctf_native_vec = _ctf_native_make_vec3_like(camera_pos, _ctf_native_point)
            if _ctf_native_vec is not None:
                _ctf_native_result.append((_ctf_native_vec, _ctf_native_point))
        return tuple(_ctf_native_result)
    except Exception:
        return ()


def _ctf_native_position(entity):
    for _ctf_native_name in ("position", "pos", "last_position"):
        try:
            _ctf_native_value = getattr(entity, _ctf_native_name)
            if callable(_ctf_native_value):
                _ctf_native_value = _ctf_native_value()
            _ctf_native_result = _ctf_native_vec3(_ctf_native_value)
            if _ctf_native_result is not None:
                return _ctf_native_result
        except Exception:
            pass
    return None


def _ctf_native_metric(entity, names, default=0.0):
    for _ctf_native_name in names:
        try:
            _ctf_native_value = getattr(entity, _ctf_native_name)
            if callable(_ctf_native_value):
                _ctf_native_value = _ctf_native_value()
            return float(_ctf_native_value)
        except Exception:
            pass
    return float(default)


def _ctf_native_max_target_distance(state):
    """Refresh the overlay-controlled range without adding per-frame file I/O."""
    _ctf_native_now = _ctf_native_time.time()
    if _ctf_native_now < state.get("next_config_refresh", 0.0):
        return state.get("max_target_distance", _ctf_native_default_max_distance)

    state["next_config_refresh"] = _ctf_native_now + 0.5
    _ctf_native_value = _ctf_native_default_max_distance
    _ctf_native_native_aim = bool(state.get("native_aim_enabled", False))
    _ctf_native_aim_fov_px = float(state.get("aim_fov_px", 0.0))
    _ctf_native_visible_only = bool(state.get("visible_only", True))
    try:
        with open(_ctf_native_config_path, "r", encoding="ascii") as _ctf_native_handle:
            for _ctf_native_line in _ctf_native_handle:
                _ctf_native_key, _ctf_native_separator, _ctf_native_raw = _ctf_native_line.partition("=")
                if not _ctf_native_separator:
                    continue
                _ctf_native_raw = _ctf_native_raw.strip()
                try:
                    if _ctf_native_key == "max_distance":
                        _ctf_native_candidate = float(_ctf_native_raw)
                        if _ctf_native_math.isfinite(_ctf_native_candidate):
                            _ctf_native_value = _ctf_native_candidate
                    elif _ctf_native_key == "native_aim":
                        _ctf_native_native_aim = _ctf_native_raw not in ("0", "false", "False")
                    elif _ctf_native_key == "aim_fov_px":
                        _ctf_native_candidate = float(_ctf_native_raw)
                        if _ctf_native_math.isfinite(_ctf_native_candidate):
                            _ctf_native_aim_fov_px = _ctf_native_candidate
                    elif _ctf_native_key == "visible_only":
                        _ctf_native_visible_only = _ctf_native_raw not in ("0", "false", "False")
                except Exception:
                    pass
    except Exception:
        pass

    state["max_target_distance"] = max(25.0, min(800.0, _ctf_native_value))
    state["native_aim_enabled"] = _ctf_native_native_aim
    state["aim_fov_px"] = max(0.0, min(1000.0, _ctf_native_aim_fov_px))
    state["visible_only"] = _ctf_native_visible_only
    return state["max_target_distance"]


def _ctf_native_rmb_down():
    global _ctf_native_user32
    try:
        if _ctf_native_user32 is None:
            import ctypes as _ctf_native_ctypes
            _ctf_native_user32 = _ctf_native_ctypes.windll.user32
        return bool(_ctf_native_user32.GetAsyncKeyState(_ctf_native_vk_rbutton) & 0x8000)
    except Exception:
        return False


def _ctf_native_external_aim_down(state):
    try:
        with open(_ctf_native_aim_trigger_path, "r", encoding="ascii") as _ctf_native_handle:
            _ctf_native_value = _ctf_native_handle.read(1)
        _ctf_native_down = _ctf_native_value == "1"
        state["native_aim_external_down"] = int(_ctf_native_down)
        return _ctf_native_down
    except Exception:
        state["native_aim_external_down"] = 0
        return False


def _ctf_native_wrap_angle_delta(source, target):
    _ctf_native_delta = (target - source + _ctf_native_math.pi) % (_ctf_native_math.pi * 2.0)
    return _ctf_native_delta - _ctf_native_math.pi


def _ctf_native_cross(left, right):
    return (
        left[1] * right[2] - left[2] * right[1],
        left[2] * right[0] - left[0] * right[2],
        left[0] * right[1] - left[1] * right[0],
    )


def _ctf_native_dot(left, right):
    return left[0] * right[0] + left[1] * right[1] + left[2] * right[2]


def _ctf_native_project_point(frame, camera_pos, screen, point):
    try:
        _ctf_native_yaw = float(frame.Yaw)
        _ctf_native_pitch = float(frame.Pitch)
        _ctf_native_roll = float(frame.Roll)
        _ctf_native_fov = max(1.0, min(150.0, float(frame.Fov)))
        _ctf_native_width = float(screen.x)
        _ctf_native_height = float(screen.y)
    except Exception:
        return None
    if _ctf_native_width <= 1.0 or _ctf_native_height <= 1.0:
        return None

    _ctf_native_cos_pitch = _ctf_native_math.cos(_ctf_native_pitch)
    _ctf_native_forward = (
        -_ctf_native_math.sin(_ctf_native_yaw) * _ctf_native_cos_pitch,
        _ctf_native_math.sin(_ctf_native_pitch),
        -_ctf_native_math.cos(_ctf_native_yaw) * _ctf_native_cos_pitch,
    )
    _ctf_native_base_right = (
        _ctf_native_math.cos(_ctf_native_yaw),
        0.0,
        -_ctf_native_math.sin(_ctf_native_yaw),
    )
    _ctf_native_base_up = _ctf_native_cross(_ctf_native_base_right, _ctf_native_forward)
    _ctf_native_cos_roll = _ctf_native_math.cos(_ctf_native_roll)
    _ctf_native_sin_roll = _ctf_native_math.sin(_ctf_native_roll)
    _ctf_native_right = (
        _ctf_native_base_right[0] * _ctf_native_cos_roll + _ctf_native_base_up[0] * _ctf_native_sin_roll,
        _ctf_native_base_right[1] * _ctf_native_cos_roll + _ctf_native_base_up[1] * _ctf_native_sin_roll,
        _ctf_native_base_right[2] * _ctf_native_cos_roll + _ctf_native_base_up[2] * _ctf_native_sin_roll,
    )
    _ctf_native_up = (
        _ctf_native_base_up[0] * _ctf_native_cos_roll - _ctf_native_base_right[0] * _ctf_native_sin_roll,
        _ctf_native_base_up[1] * _ctf_native_cos_roll - _ctf_native_base_right[1] * _ctf_native_sin_roll,
        _ctf_native_base_up[2] * _ctf_native_cos_roll - _ctf_native_base_right[2] * _ctf_native_sin_roll,
    )
    _ctf_native_relative = (
        point[0] - camera_pos[0],
        point[1] - camera_pos[1],
        point[2] - camera_pos[2],
    )
    _ctf_native_depth = _ctf_native_dot(_ctf_native_relative, _ctf_native_forward)
    if _ctf_native_depth <= 0.08:
        return None

    _ctf_native_fov_radians = _ctf_native_fov * _ctf_native_math.pi / 180.0
    _ctf_native_focal_y = _ctf_native_height / (2.0 * _ctf_native_math.tan(_ctf_native_fov_radians * 0.5))
    _ctf_native_x = _ctf_native_width * 0.5 + _ctf_native_dot(_ctf_native_relative, _ctf_native_right) * _ctf_native_focal_y / _ctf_native_depth
    _ctf_native_y = _ctf_native_height * 0.5 - _ctf_native_dot(_ctf_native_relative, _ctf_native_up) * _ctf_native_focal_y / _ctf_native_depth
    if not (_ctf_native_math.isfinite(_ctf_native_x) and _ctf_native_math.isfinite(_ctf_native_y)):
        return None
    return _ctf_native_x, _ctf_native_y


def _ctf_native_head_angles(frame, camera_pos, head):
    _ctf_native_vector = (
        head[0] - camera_pos[0],
        head[1] - camera_pos[1],
        head[2] - camera_pos[2],
    )
    _ctf_native_horizontal = _ctf_native_math.hypot(_ctf_native_vector[0], _ctf_native_vector[2])
    if _ctf_native_horizontal <= 0.001:
        return None
    _ctf_native_yaw = _ctf_native_math.atan2(-_ctf_native_vector[0], -_ctf_native_vector[2])
    _ctf_native_pitch = _ctf_native_math.atan2(_ctf_native_vector[1], _ctf_native_horizontal)
    if not (_ctf_native_math.isfinite(_ctf_native_yaw) and _ctf_native_math.isfinite(_ctf_native_pitch)):
        return None
    return _ctf_native_yaw, max(-1.55, min(1.55, _ctf_native_pitch))


def _ctf_native_find_native_aim_target(state, frame, camera_pos, screen, rows):
    try:
        _ctf_native_width = float(screen.x)
        _ctf_native_height = float(screen.y)
    except Exception:
        return None
    _ctf_native_radius = float(state.get("aim_fov_px", 0.0))
    if _ctf_native_radius <= 1.0:
        _ctf_native_radius = max(78.0, _ctf_native_height * 0.20)
    _ctf_native_center_x = _ctf_native_width * 0.5
    _ctf_native_center_y = _ctf_native_height * 0.5
    _ctf_native_locked_key = state.get("native_aim_lock_key")
    _ctf_native_best = None

    for _ctf_native_row in rows:
        (
            _ctf_native_key,
            _ctf_native_pos,
            _ctf_native_low,
            _ctf_native_high,
            _ctf_native_hp,
            _ctf_native_maxhp,
            _ctf_native_armor,
            _ctf_native_maxarmor,
            _ctf_native_dead,
            _ctf_native_head,
            _ctf_native_is_visible,
            _ctf_native_is_robot,
            _ctf_native_relation,
        ) = _ctf_native_row
        if _ctf_native_dead or _ctf_native_head is None:
            continue
        if _ctf_native_relation != 2:
            continue
        if not _ctf_native_is_visible:
            continue
        _ctf_native_projected = _ctf_native_project_point(frame, camera_pos, screen, _ctf_native_head)
        if _ctf_native_projected is None:
            continue
        _ctf_native_dx = _ctf_native_projected[0] - _ctf_native_center_x
        _ctf_native_dy = _ctf_native_projected[1] - _ctf_native_center_y
        _ctf_native_distance = _ctf_native_math.hypot(_ctf_native_dx, _ctf_native_dy)
        _ctf_native_limit = _ctf_native_radius * (1.45 if _ctf_native_key == _ctf_native_locked_key else 1.0)
        if _ctf_native_distance > _ctf_native_limit:
            continue
        _ctf_native_angles = _ctf_native_head_angles(frame, camera_pos, _ctf_native_head)
        if _ctf_native_angles is None:
            continue
        _ctf_native_candidate = (_ctf_native_distance, _ctf_native_key, _ctf_native_head, _ctf_native_angles)
        if _ctf_native_key == _ctf_native_locked_key:
            return _ctf_native_candidate
        if _ctf_native_best is None or _ctf_native_distance < _ctf_native_best[0]:
            _ctf_native_best = _ctf_native_candidate
    return _ctf_native_best


def _ctf_native_apply_native_aim(state, camera, frame, camera_pos, screen, rows):
    if not state.get("native_aim_enabled", True):
        state["native_aim_lock_key"] = None
        return frame
    _ctf_native_trigger_down = _ctf_native_rmb_down() or _ctf_native_external_aim_down(state)
    state["native_aim_trigger_down"] = int(_ctf_native_trigger_down)
    if not _ctf_native_trigger_down:
        state["native_aim_lock_key"] = None
        return frame
    state["native_aim_trigger_seen"] = state.get("native_aim_trigger_seen", 0) + 1

    _ctf_native_target = _ctf_native_find_native_aim_target(
        state, frame, camera_pos, screen, rows
    )
    if _ctf_native_target is None:
        state["native_aim_lock_key"] = None
        state["native_aim_candidate_miss"] = state.get("native_aim_candidate_miss", 0) + 1
        return frame

    _ctf_native_yaw, _ctf_native_pitch = _ctf_native_target[3]
    try:
        _ctf_native_apply_frame = camera.CaptureFrame()
        _ctf_native_apply_frame.Yaw = _ctf_native_yaw
        _ctf_native_apply_frame.Pitch = _ctf_native_pitch
        try:
            _ctf_native_apply_frame.Roll = 0.0
        except Exception:
            pass
        for _ctf_native_attr, _ctf_native_value in (("InterpolateMode", 0), ("Time", 0.0)):
            try:
                setattr(_ctf_native_apply_frame, _ctf_native_attr, _ctf_native_value)
            except Exception:
                pass
        camera.ApplyFrame(_ctf_native_apply_frame)
        state["native_aim_lock_key"] = _ctf_native_target[1]
        state["native_aim_applied"] = state.get("native_aim_applied", 0) + 1
        return camera.CaptureFrame()
    except Exception as _ctf_native_exc:
        _ctf_native_error = repr(_ctf_native_exc)[:160]
        if state.get("native_aim_last_error") != _ctf_native_error:
            state["native_aim_last_error"] = _ctf_native_error
            _ctf_native_log("NATIVE_AIM_EXC {}".format(_ctf_native_error))
        return frame


def _ctf_native_probe_apply_frame(state):
    try:
        import MCamera as _ctf_native_camera
        _ctf_native_frame = _ctf_native_camera.CaptureFrame()
        _ctf_native_camera.ApplyFrame(_ctf_native_frame)
        state["native_apply_frame_ok"] = True
        state["native_apply_frame_error"] = ""
    except Exception as _ctf_native_exc:
        state["native_apply_frame_ok"] = False
        state["native_apply_frame_error"] = repr(_ctf_native_exc)[:160]


def _ctf_native_bounds(entity):
    for _ctf_native_source in (getattr(entity, "model", None), entity):
        if _ctf_native_source is None:
            continue
        for _ctf_native_name in ("GetWorldBound", "GetPrimWorldBound", "GetSkeletonDynamicWorldBound"):
            _ctf_native_bound = _ctf_native_call(_ctf_native_source, _ctf_native_name)
            if _ctf_native_bound is None:
                continue
            _ctf_native_low = _ctf_native_vec3(getattr(_ctf_native_bound, "min", None))
            _ctf_native_high = _ctf_native_vec3(getattr(_ctf_native_bound, "max", None))
            if _ctf_native_low is None or _ctf_native_high is None:
                continue
            if _ctf_native_high[1] > _ctf_native_low[1]:
                return _ctf_native_low, _ctf_native_high
    return None, None


def _ctf_native_head_position(state, key, entity, entity_pos):
    """Return the current model head/upper-body point for posture-safe aiming."""
    _ctf_native_model = getattr(entity, "model", None)
    if _ctf_native_model is None:
        return None

    _ctf_native_head_models = state.setdefault("head_models", {})
    _ctf_native_model_id = id(_ctf_native_model)
    if _ctf_native_head_models.get(key) != _ctf_native_model_id:
        _ctf_native_ensure_aim_bones(state, key, _ctf_native_model)
        _ctf_native_head_models[key] = _ctf_native_model_id

    # Refresh the skeleton immediately before reading the bone.  This keeps
    # the exported point tied to the same animation frame as CameraFrame.
    _ctf_native_call(_ctf_native_model, "MakeSureBones")

    _ctf_native_low, _ctf_native_high = _ctf_native_bounds(entity)
    for _ctf_native_bone in ("biped Head", "biped Neck", "biped Spine2"):
        _ctf_native_head = _ctf_native_vec3(
            _ctf_native_call(_ctf_native_model, "GetBoneWorldPosition", _ctf_native_bone)
        )
        if _ctf_native_head is None or not all(_ctf_native_math.isfinite(value) for value in _ctf_native_head):
            continue
        if not _ctf_native_point_in_bounds(_ctf_native_head, _ctf_native_low, _ctf_native_high):
            continue
        # The head can legitimately be below the entity origin while crouching
        # or sliding.  Only reject clearly detached stale bones.
        if entity_pos is not None:
            _ctf_native_offset = (
                _ctf_native_head[0] - entity_pos[0],
                _ctf_native_head[1] - entity_pos[1],
                _ctf_native_head[2] - entity_pos[2],
            )
            if _ctf_native_math.sqrt(_ctf_native_dot(_ctf_native_offset, _ctf_native_offset)) > 8.0:
                continue
        return _ctf_native_head
    return None


def _ctf_native_active_space(state):
    _ctf_native_space = state.get("physics_space")
    if _ctf_native_space is not None:
        return _ctf_native_space
    try:
        from gclient.framework.entities.space import Space as _ctf_native_space_class
        _ctf_native_spaces = [
            space for space in _ctf_native_gc.get_objects()
            if isinstance(space, _ctf_native_space_class)
        ]
        # The active scene is the non-disposed Space instance.  Disposed spaces
        # retain a '(D)' suffix while the shooting-range scene remains live.
        _ctf_native_space = next(
            (space for space in _ctf_native_spaces if "(D)" not in repr(space)),
            None,
        )
        if _ctf_native_space is not None:
            state["physics_space"] = _ctf_native_space
        return _ctf_native_space
    except Exception:
        return None


def _ctf_native_visibility_filter_values(state):
    _ctf_native_filters = state.get("visibility_filter_values")
    if _ctf_native_filters is not None:
        return _ctf_native_filters
    _ctf_native_filters = ()
    try:
        from gclient import cconst as _ctf_native_cconst
        _ctf_native_values = []
        for _ctf_native_name in (
            "PHYSICS_VISIBLE_OBSTACLE_QUERY",
            "PHYSICS_OBSTACLE_QUERY",
            "PHYSICS_SHOOT_VERIFY",
            "PHYSICS_CAMERA",
            "PHYSICS_BULLET",
            "PHYSICS_THROWN",
        ):
            _ctf_native_value = getattr(_ctf_native_cconst, _ctf_native_name, None)
            if isinstance(_ctf_native_value, int) and _ctf_native_value not in _ctf_native_values:
                _ctf_native_values.append(_ctf_native_value)
        _ctf_native_filters = tuple(_ctf_native_values)
    except Exception:
        _ctf_native_filters = ()
    state["visibility_filter_values"] = _ctf_native_filters
    return _ctf_native_filters


def _ctf_native_distance(a, b):
    if a is None or b is None:
        return None
    try:
        return _ctf_native_math.sqrt(
            (a[0] - b[0]) * (a[0] - b[0]) +
            (a[1] - b[1]) * (a[1] - b[1]) +
            (a[2] - b[2]) * (a[2] - b[2])
        )
    except Exception:
        return None


def _ctf_native_hit_position(hit):
    for _ctf_native_name in (
        "Pos",
        "HitPos",
        "HitPosition",
        "position",
        "point",
        "Point",
        "hit_pos",
        "hitPoint",
        "HitPoint",
    ):
        _ctf_native_pos = _ctf_native_vec3(getattr(hit, _ctf_native_name, None))
        if _ctf_native_pos is not None:
            return _ctf_native_pos
    return None


def _ctf_native_collision_distance(hit):
    for _ctf_native_name in ("Distance", "distance", "Dist", "dist"):
        try:
            _ctf_native_value = float(getattr(hit, _ctf_native_name))
            if _ctf_native_math.isfinite(_ctf_native_value) and _ctf_native_value >= 0.0:
                return _ctf_native_value
        except Exception:
            pass
    return None


def _ctf_native_environment_blocked(state, space, camera_pos, point):
    _ctf_native_camera = _ctf_native_vec3(camera_pos)
    _ctf_native_point = _ctf_native_vec3(point)
    _ctf_native_target_distance = _ctf_native_distance(_ctf_native_camera, _ctf_native_point)
    for _ctf_native_filter in _ctf_native_visibility_filter_values(state):
        _ctf_native_hit = _ctf_native_call(
            space, "ClosestRaycast", camera_pos, point, _ctf_native_filter, False
        )
        if _ctf_native_hit is not None and getattr(_ctf_native_hit, "IsHit", False):
            _ctf_native_hit_pos = _ctf_native_hit_position(_ctf_native_hit)
            _ctf_native_hit_distance = _ctf_native_distance(_ctf_native_camera, _ctf_native_hit_pos)
            if _ctf_native_hit_distance is None:
                _ctf_native_hit_distance = _ctf_native_collision_distance(_ctf_native_hit)
            if _ctf_native_hit_distance is not None:
                if _ctf_native_hit_distance <= 0.85:
                    state["visibility_near_hit_count"] = state.get("visibility_near_hit_count", 0) + 1
                    continue
                if (
                    _ctf_native_target_distance is not None and
                    _ctf_native_hit_distance >= _ctf_native_target_distance - 0.30
                ):
                    continue
            elif _ctf_native_hit_pos is None:
                state["visibility_unknown_hit_count"] = state.get("visibility_unknown_hit_count", 0) + 1
                continue
            state["visibility_env_block_count"] = state.get("visibility_env_block_count", 0) + 1
            state["visibility_env_last_filter"] = _ctf_native_filter
            return True
    return False


def _ctf_native_target_skeleton_hit(space, camera_pos, point, skeleton):
    _ctf_native_hits = _ctf_native_call(
        space, "RaycastBoneWithPenetrate", camera_pos, point
    )
    if isinstance(_ctf_native_hits, (list, tuple)):
        return bool(
            len(_ctf_native_hits) == 1 and
            getattr(_ctf_native_hits[0], "IsHit", False) and
            getattr(_ctf_native_hits[0], "actor", None) == skeleton
        )
    _ctf_native_hit = _ctf_native_call(
        space, "ClosestRaycastBone", camera_pos, point
    )
    return bool(
        _ctf_native_hit is not None and
        getattr(_ctf_native_hit, "IsHit", False) and
        getattr(_ctf_native_hit, "actor", None) == skeleton
    )


def _ctf_native_visible(state, key, entity, camera_pos):
    """Use the game physics scene so aim assist never selects a wall-blocked head."""
    _ctf_native_now = _ctf_native_time.time()
    _ctf_native_cache = state.setdefault("visibility_cache", {})
    _ctf_native_aim_points = state.setdefault("visibility_aim_points", {})
    _ctf_native_cached = _ctf_native_cache.get(key)
    if _ctf_native_cached is not None and _ctf_native_now - _ctf_native_cached[0] < (1.0 / 120.0):
        return _ctf_native_cached[1]
    _ctf_native_aim_points.pop(key, None)

    _ctf_native_model = getattr(entity, "model", None)
    _ctf_native_space = _ctf_native_active_space(state)
    if _ctf_native_model is None or _ctf_native_space is None:
        _ctf_native_cache[key] = (_ctf_native_now, False)
        return False
    _ctf_native_ensure_aim_bones(state, key, _ctf_native_model)
    _ctf_native_call(_ctf_native_model, "MakeSureBones")
    _ctf_native_skeleton = _ctf_native_call(_ctf_native_model, "GetSkeleton")
    _ctf_native_low, _ctf_native_high = _ctf_native_bounds(entity)
    _ctf_native_posture_fallback = None
    for _ctf_native_bone in _ctf_native_aim_bones:
        _ctf_native_point = _ctf_native_call(
            _ctf_native_model, "GetBoneWorldPosition", _ctf_native_bone
        )
        _ctf_native_point_tuple = _ctf_native_vec3(_ctf_native_point)
        if (
            _ctf_native_point_tuple is None or
            not all(_ctf_native_math.isfinite(value) for value in _ctf_native_point_tuple)
        ):
            continue
        if not _ctf_native_point_in_bounds(_ctf_native_point_tuple, _ctf_native_low, _ctf_native_high):
            continue
        if _ctf_native_environment_blocked(
            state, _ctf_native_space, camera_pos, _ctf_native_point
        ):
            continue
        if not _ctf_native_target_skeleton_hit(
            _ctf_native_space, camera_pos, _ctf_native_point, _ctf_native_skeleton
        ):
            if _ctf_native_posture_fallback is None and _ctf_native_bone != "biped Pelvis":
                _ctf_native_posture_fallback = _ctf_native_point_tuple
            state["visibility_skeleton_miss_count"] = state.get("visibility_skeleton_miss_count", 0) + 1
            continue
        _ctf_native_aim_points[key] = _ctf_native_point_tuple
        _ctf_native_cache[key] = (_ctf_native_now, True)
        return True
    if _ctf_native_posture_fallback is None:
        for _ctf_native_point, _ctf_native_point_tuple in _ctf_native_upper_body_fallback_points(
            camera_pos, _ctf_native_low, _ctf_native_high
        ):
            if _ctf_native_environment_blocked(
                state, _ctf_native_space, camera_pos, _ctf_native_point
            ):
                continue
            _ctf_native_posture_fallback = _ctf_native_point_tuple
            break
    if _ctf_native_posture_fallback is not None:
        state["visibility_posture_fallback_count"] = state.get("visibility_posture_fallback_count", 0) + 1
        _ctf_native_aim_points[key] = _ctf_native_posture_fallback
        _ctf_native_cache[key] = (_ctf_native_now, True)
        return True
    _ctf_native_cache[key] = (_ctf_native_now, False)
    return False


def _ctf_native_hide_widget(widget):
    if widget is None:
        return
    for _ctf_native_attr, _ctf_native_value in (("visible", False), ("opacity", 0), ("text", "")):
        try:
            setattr(widget, _ctf_native_attr, _ctf_native_value)
        except Exception:
            pass
    for _ctf_native_name, _ctf_native_args in (
        ("setVisible", (False,)),
        ("SetVisible", (False,)),
        ("SetHiddenReason", (True, 918273,)),
    ):
        _ctf_native_call(widget, _ctf_native_name, *_ctf_native_args)


def _ctf_native_suppress_legacy_widgets(robot):
    """Remove the prior fixed UI marker so only the projected C++ box remains."""
    _ctf_native_frame = getattr(robot, "recon_drone_frame_top_logo", None)
    if _ctf_native_frame is not None:
        for _ctf_native_attr in ("ui_node_top_logo", "scene_node", "panel_frame"):
            _ctf_native_hide_widget(getattr(_ctf_native_frame, _ctf_native_attr, None))
    _ctf_native_toplogo = getattr(robot, "toplogo", None)
    if _ctf_native_toplogo is not None:
        for _ctf_native_attr in (
            "toplogo_widget",
            "node_name_hp",
            "text_dis_friend",
            "text_name_enemy",
        ):
            _ctf_native_hide_widget(getattr(_ctf_native_toplogo, _ctf_native_attr, None))


def _ctf_native_stop_legacy_timer():
    _ctf_native_old = getattr(_ctf_native_builtins, _ctf_native_legacy_state_name, None)
    if not isinstance(_ctf_native_old, dict):
        return
    _ctf_native_owner = _ctf_native_old.get("timer_owner")
    _ctf_native_timer = _ctf_native_old.get("timer_id")
    if _ctf_native_owner is not None and _ctf_native_timer is not None:
        _ctf_native_call(_ctf_native_owner, "cancel_timer", _ctf_native_timer)
    _ctf_native_old["timer_id"] = None
    _ctf_native_old["timer_owner"] = None


def _ctf_native_entities():
    import common.EntityManager as _ctf_native_em

    _ctf_native_values = getattr(_ctf_native_em.EntityManager, "_entities", {}).items()
    _ctf_native_players = []
    _ctf_native_robots = []
    for _ctf_native_key, _ctf_native_entity in list(_ctf_native_values):
        try:
            _ctf_native_type_name = type(_ctf_native_entity).__name__.lower()
            _ctf_native_is_robot = _ctf_native_flag(_ctf_native_entity, "IsRobotCombatAvatar")
            _ctf_native_is_player = _ctf_native_flag(_ctf_native_entity, "IsPlayerCombatAvatar")
            if _ctf_native_is_robot:
                _ctf_native_robots.append((str(_ctf_native_key), _ctf_native_entity))
            elif _ctf_native_is_player:
                _ctf_native_players.append((str(_ctf_native_key), _ctf_native_entity))
            elif _ctf_native_is_combat_avatar(_ctf_native_entity):
                # Some real players are exposed as the base CombatAvatarMoba
                # class while their player flag is still false.  Robots keep
                # the robot class/flag and everything else is a player.
                if "robot" in _ctf_native_type_name:
                    _ctf_native_robots.append((str(_ctf_native_key), _ctf_native_entity))
                else:
                    _ctf_native_players.append((str(_ctf_native_key), _ctf_native_entity))
        except Exception:
            pass
    return _ctf_native_players, _ctf_native_robots


def _ctf_native_flag(entity, name):
    try:
        _ctf_native_value = getattr(entity, name)
        if callable(_ctf_native_value):
            _ctf_native_value = _ctf_native_value()
        return bool(_ctf_native_value)
    except Exception:
        return False


def _ctf_native_bool_probe(entity, names):
    """Return an explicit boolean only when the game exposes one."""
    for _ctf_native_name in names:
        try:
            _ctf_native_value = getattr(entity, _ctf_native_name)
            if callable(_ctf_native_value):
                _ctf_native_value = _ctf_native_value()
            if isinstance(_ctf_native_value, bool):
                return True, _ctf_native_value
        except Exception:
            pass
    return False, False


def _ctf_native_scalar_probe(entity, names):
    for _ctf_native_name in names:
        try:
            _ctf_native_value = getattr(entity, _ctf_native_name)
            if callable(_ctf_native_value):
                _ctf_native_value = _ctf_native_value()
            if isinstance(_ctf_native_value, bool):
                continue
            if isinstance(_ctf_native_value, (str, int, float)):
                return str(_ctf_native_value)
            for _ctf_native_child_name in (
                "id", "guid", "key", "team_id", "teamId", "teamID", "code"
            ):
                _ctf_native_child = getattr(_ctf_native_value, _ctf_native_child_name, None)
                if callable(_ctf_native_child):
                    _ctf_native_child = _ctf_native_child()
                if isinstance(_ctf_native_child, (str, int, float)) and not isinstance(_ctf_native_child, bool):
                    return str(_ctf_native_child)
        except Exception:
            pass
    return None


def _ctf_native_identity_candidates(key, entity):
    _ctf_native_candidates = [str(key)]
    for _ctf_native_name in (
        "id", "guid", "key", "entity_id", "player_id", "player_guid",
        "combat_avatar_id", "avatar_id"
    ):
        try:
            _ctf_native_value = getattr(entity, _ctf_native_name)
            if callable(_ctf_native_value):
                _ctf_native_value = _ctf_native_value()
            if isinstance(_ctf_native_value, (str, int, float)) and not isinstance(_ctf_native_value, bool):
                _ctf_native_text = str(_ctf_native_value)
                if _ctf_native_text and _ctf_native_text not in _ctf_native_candidates:
                    _ctf_native_candidates.append(_ctf_native_text)
        except Exception:
            pass
    return _ctf_native_candidates


def _ctf_native_team_relation(local_player, target_key, target, is_robot):
    """Use explicit team APIs first; do not infer a team from screen position."""
    _ctf_native_has_value, _ctf_native_value = _ctf_native_bool_probe(
        target, ("is_teammate", "is_team_mate", "IsTeammate", "IsTeamMate", "is_friend", "IsFriend")
    )
    if _ctf_native_has_value:
        return 1 if _ctf_native_value else 2

    _ctf_native_has_value, _ctf_native_value = _ctf_native_bool_probe(
        target, ("is_enemy", "IsEnemy", "enemy", "is_hostile", "IsHostile")
    )
    if _ctf_native_has_value:
        return 2 if _ctf_native_value else 1

    _ctf_native_local_team = _ctf_native_scalar_probe(
        local_player,
        ("team_id", "teamId", "teamID", "camp_id", "campId", "camp", "faction_id", "factionId", "faction"),
    )
    _ctf_native_target_team = _ctf_native_scalar_probe(
        target,
        ("team_id", "teamId", "teamID", "camp_id", "campId", "camp", "faction_id", "factionId", "faction"),
    )
    if _ctf_native_local_team is not None and _ctf_native_target_team is not None:
        return 1 if _ctf_native_local_team == _ctf_native_target_team else 2

    _ctf_native_target_ids = _ctf_native_identity_candidates(target_key, target)
    if local_player is not None:
        try:
            _ctf_native_teammates = getattr(local_player, "teammate_info")
            if isinstance(_ctf_native_teammates, dict):
                for _ctf_native_target_id in _ctf_native_target_ids:
                    if _ctf_native_target_id in _ctf_native_teammates:
                        return 1
            elif isinstance(_ctf_native_teammates, (set, list, tuple)):
                for _ctf_native_target_id in _ctf_native_target_ids:
                    if _ctf_native_target_id in _ctf_native_teammates:
                        return 1
        except Exception:
            pass

        _ctf_native_get_info = getattr(local_player, "GetTeammateInfo", None)
        if callable(_ctf_native_get_info):
            for _ctf_native_target_id in _ctf_native_target_ids:
                try:
                    _ctf_native_info = _ctf_native_get_info(_ctf_native_target_id)
                    if _ctf_native_info not in (None, False, {}, [], ()):
                        return 1
                except Exception:
                    pass

    _ctf_native_has_value, _ctf_native_value = _ctf_native_bool_probe(
        target, ("CanShowEnemyToplogo", "CanShowEnemyToplogoBar")
    )
    if _ctf_native_has_value and _ctf_native_value:
        return 2
    # Shooting-range robots have no team object, but are authoritative enemy
    # targets in this mode.  Keep the label useful while preserving unknown
    # for player entities whose team state is unavailable during transitions.
    if is_robot:
        return 2
    return 0


def _ctf_native_is_combat_avatar(entity):
    if _ctf_native_flag(entity, "IsCombatAvatar"):
        return True
    _ctf_native_type_name = type(entity).__name__.lower()
    return _ctf_native_type_name.endswith("combatavatarmoba")


def _ctf_native_timer_owner(players, robots):
    """Use a live game object as the timer owner, including in the lobby."""
    _ctf_native_candidates = [
        _ctf_native_entity
        for _ctf_native_key, _ctf_native_entity in players + robots
    ]
    try:
        import common.EntityManager as _ctf_native_em
        _ctf_native_candidates.extend(
            getattr(_ctf_native_em.EntityManager, "_entities", {}).values()
        )
    except Exception:
        pass

    _ctf_native_seen = set()
    for _ctf_native_candidate in _ctf_native_candidates:
        if id(_ctf_native_candidate) in _ctf_native_seen:
            continue
        _ctf_native_seen.add(id(_ctf_native_candidate))
        if callable(getattr(_ctf_native_candidate, "add_repeat_timer", None)):
            return _ctf_native_candidate
    return None


def _ctf_native_local_player(state, players):
    """Keep the controlled player out of the target stream across entity reorderings."""
    _ctf_native_local_key = state.get("local_key")
    for _ctf_native_key, _ctf_native_entity in players:
        if _ctf_native_key == _ctf_native_local_key:
            return _ctf_native_key, _ctf_native_entity

    try:
        import common.EntityManager as _ctf_native_em
        _ctf_native_all_entities = list(
            getattr(_ctf_native_em.EntityManager, "_entities", {}).values()
        )
    except Exception:
        _ctf_native_all_entities = []

    # GameLogicMoba keeps the authoritative reference to the controlled
    # combat avatar.  Prefer object identity over list order.
    for _ctf_native_manager in _ctf_native_all_entities:
        try:
            _ctf_native_candidate = getattr(_ctf_native_manager, "player")
            if callable(_ctf_native_candidate):
                _ctf_native_candidate = _ctf_native_candidate()
            for _ctf_native_key, _ctf_native_entity in players:
                if _ctf_native_entity is _ctf_native_candidate:
                    state["local_key"] = _ctf_native_key
                    return _ctf_native_key, _ctf_native_entity
        except Exception:
            pass

    # The hall profile name is a stable fallback when the game-logic reference
    # is temporarily unavailable during a scene transition.
    _ctf_native_profile_names = set()
    for _ctf_native_entity in _ctf_native_all_entities:
        if type(_ctf_native_entity).__name__ != "PlayerAvatar":
            continue
        try:
            _ctf_native_name = getattr(_ctf_native_entity, "name")
            if isinstance(_ctf_native_name, str) and _ctf_native_name:
                _ctf_native_profile_names.add(_ctf_native_name)
        except Exception:
            pass
    for _ctf_native_key, _ctf_native_entity in players:
        try:
            if getattr(_ctf_native_entity, "name") in _ctf_native_profile_names:
                state["local_key"] = _ctf_native_key
                return _ctf_native_key, _ctf_native_entity
        except Exception:
            pass

    for _ctf_native_key, _ctf_native_entity in players:
        for _ctf_native_name in ("is_main_player", "is_local_player", "is_self", "IsMainPlayer"):
            try:
                _ctf_native_value = getattr(_ctf_native_entity, _ctf_native_name)
                if callable(_ctf_native_value):
                    _ctf_native_value = _ctf_native_value()
                if _ctf_native_value:
                    state["local_key"] = _ctf_native_key
                    return _ctf_native_key, _ctf_native_entity
            except Exception:
                pass

    if len(players) == 1:
        _ctf_native_key, _ctf_native_entity = players[0]
        state["local_key"] = _ctf_native_key
        return _ctf_native_key, _ctf_native_entity
    # Never guess the local avatar from an unordered multi-player list.
    return None, None


def _ctf_native_active_weapon_ballistics(player):
    """Read equipped projectile data after weapon parts/modifiers are applied."""
    if player is None:
        return 0, 0.0, 0.0
    weapon = _ctf_native_call(player, "GetCurHighPriorityWeapon")
    if weapon is None:
        return 0, 0.0, 0.0

    try:
        item_id = int(getattr(weapon, "item_id", 0) or 0)
    except Exception:
        item_id = 0

    base_speed = 0.0
    base_gravity = 0.0
    try:
        proto = getattr(weapon, "weapon_proto", None)
        if proto is not None:
            if hasattr(proto, "get"):
                base_speed = float(proto.get("bullet_velocity", 0.0) or 0.0)
                base_gravity = float(proto.get("bullet_gravity", 0.0) or 0.0)
            else:
                base_speed = float(getattr(proto, "bullet_velocity", 0.0) or 0.0)
                base_gravity = float(getattr(proto, "bullet_gravity", 0.0) or 0.0)
    except Exception:
        pass

    # This resolves the currently equipped weapon case, including compatible mods.
    effective_speed = _ctf_native_call(
        player,
        "GetWeaponAttrValueWithCache",
        "bullet_velocity",
        base_speed,
        0.10,
    )
    try:
        speed = float(effective_speed)
    except Exception:
        speed = base_speed
    effective_gravity = _ctf_native_call(
        player,
        "GetWeaponAttrValueWithCache",
        "bullet_gravity",
        base_gravity,
        0.10,
    )
    try:
        gravity = abs(float(effective_gravity))
    except Exception:
        gravity = abs(base_gravity)
    # Reject multipliers and malformed values.  A confirmed gravity value is
    # in world acceleration units; zero means this weapon has no exported drop.
    if not _ctf_native_math.isfinite(gravity) or gravity < 0.10 or gravity > 30.0:
        gravity = 0.0
    return item_id, speed if speed > 0.0 else 0.0, gravity


def _ctf_native_write_snapshot(state):
    import MCamera as _ctf_native_camera
    import MUI as _ctf_native_ui

    _ctf_native_players, _ctf_native_robots = _ctf_native_entities()
    _ctf_native_local_key, _ctf_native_player = _ctf_native_local_player(state, _ctf_native_players)
    _ctf_native_player_pos = _ctf_native_position(_ctf_native_player) if _ctf_native_player is not None else (0.0, 0.0, 0.0)
    (
        _ctf_native_weapon_item_id,
        _ctf_native_projectile_speed,
        _ctf_native_projectile_gravity,
    ) = _ctf_native_active_weapon_ballistics(_ctf_native_player)
    _ctf_native_frame = _ctf_native_camera.CaptureFrame()
    _ctf_native_camera_pos = _ctf_native_vec3(_ctf_native_frame.Position) or (0.0, 0.0, 0.0)
    _ctf_native_screen = _ctf_native_ui.GetScreenSize()
    _ctf_native_rows = []

    _ctf_native_targets = [
        (_ctf_native_key, _ctf_native_entity, False)
        for _ctf_native_key, _ctf_native_entity in _ctf_native_players
        if _ctf_native_key != _ctf_native_local_key
    ] + [
        (_ctf_native_key, _ctf_native_entity, True)
        for _ctf_native_key, _ctf_native_entity in _ctf_native_robots
    ]
    state["last_player_targets"] = len(_ctf_native_targets) - len(_ctf_native_robots)
    state["last_robot_targets"] = len(_ctf_native_robots)
    _ctf_native_visible_count = 0
    _ctf_native_range = _ctf_native_max_target_distance(state)
    _ctf_native_range_sq = _ctf_native_range * _ctf_native_range
    _ctf_native_culled_targets = 0
    _ctf_native_detected_players = 0
    _ctf_native_detected_robots = 0

    for _ctf_native_key, _ctf_native_target, _ctf_native_is_robot in _ctf_native_targets:
        _ctf_native_pos = _ctf_native_position(_ctf_native_target)
        if _ctf_native_pos is None:
            continue
        if _ctf_native_player is not None:
            _ctf_native_dx = _ctf_native_pos[0] - _ctf_native_player_pos[0]
            _ctf_native_dy = _ctf_native_pos[1] - _ctf_native_player_pos[1]
            _ctf_native_dz = _ctf_native_pos[2] - _ctf_native_player_pos[2]
            if _ctf_native_dx * _ctf_native_dx + _ctf_native_dy * _ctf_native_dy + _ctf_native_dz * _ctf_native_dz > _ctf_native_range_sq:
                _ctf_native_culled_targets += 1
                continue
        _ctf_native_suppress_legacy_widgets(_ctf_native_target)
        _ctf_native_low, _ctf_native_high = _ctf_native_bounds(_ctf_native_target)
        if _ctf_native_low is None or _ctf_native_high is None:
            continue
        _ctf_native_head = _ctf_native_head_position(
            state, _ctf_native_key, _ctf_native_target, _ctf_native_pos
        )
        _ctf_native_relation = _ctf_native_team_relation(
            _ctf_native_player,
            _ctf_native_key,
            _ctf_native_target,
            _ctf_native_is_robot,
        )
        _ctf_native_is_visible = _ctf_native_visible(
            state, _ctf_native_key, _ctf_native_target, _ctf_native_frame.Position
        )
        if _ctf_native_is_visible:
            _ctf_native_head = state.get("visibility_aim_points", {}).get(
                _ctf_native_key, _ctf_native_head
            )
        _ctf_native_visible_count += int(_ctf_native_is_visible)
        _ctf_native_hp = _ctf_native_metric(_ctf_native_target, ("hp", "server_hp", "client_hp", "_hp"), 0.0)
        _ctf_native_maxhp = _ctf_native_metric(_ctf_native_target, ("cur_maxhp", "maxhp", "base_maxhp", "server_maxhp"), max(1.0, _ctf_native_hp))
        _ctf_native_armor = _ctf_native_metric(_ctf_native_target, ("client_armor", "armor", "_client_armor", "server_armor"), 0.0)
        _ctf_native_maxarmor = _ctf_native_metric(_ctf_native_target, ("base_maxarmor", "maxarmor", "server_maxarmor"), max(0.0, _ctf_native_armor))
        _ctf_native_dead = int(bool(getattr(_ctf_native_target, "is_dead_state", False) or getattr(_ctf_native_target, "dead", False)))
        _ctf_native_rows.append((
            _ctf_native_key,
            _ctf_native_pos,
            _ctf_native_low,
            _ctf_native_high,
            _ctf_native_hp,
            _ctf_native_maxhp,
            _ctf_native_armor,
            _ctf_native_maxarmor,
            _ctf_native_dead,
            _ctf_native_head,
            _ctf_native_is_visible,
            _ctf_native_is_robot,
            _ctf_native_relation,
        ))
        if _ctf_native_is_robot:
            _ctf_native_detected_robots += 1
        else:
            _ctf_native_detected_players += 1

    _ctf_native_header = (
        "ESP1 {:.6f} {} {} {:.6f} {:.6f} {:.6f} {:.9f} {:.9f} {:.9f} {:.6f} "
        "{:.6f} {:.6f} {:.6f} {}\n"
    ).format(
        _ctf_native_time.time(),
        int(_ctf_native_screen.x),
        int(_ctf_native_screen.y),
        _ctf_native_camera_pos[0],
        _ctf_native_camera_pos[1],
        _ctf_native_camera_pos[2],
        float(_ctf_native_frame.Yaw),
        float(_ctf_native_frame.Pitch),
        float(_ctf_native_frame.Roll),
        float(_ctf_native_frame.Fov),
        _ctf_native_player_pos[0],
        _ctf_native_player_pos[1],
        _ctf_native_player_pos[2],
        len(_ctf_native_rows),
    )
    _ctf_native_lines = [_ctf_native_header]
    for _ctf_native_row in _ctf_native_rows:
        (
            _ctf_native_key,
            _ctf_native_pos,
            _ctf_native_low,
            _ctf_native_high,
            _ctf_native_hp,
            _ctf_native_maxhp,
            _ctf_native_armor,
            _ctf_native_maxarmor,
            _ctf_native_dead,
            _ctf_native_head,
            _ctf_native_is_visible,
            _ctf_native_is_robot,
            _ctf_native_relation,
        ) = _ctf_native_row
        _ctf_native_has_head = int(_ctf_native_head is not None)
        _ctf_native_head = _ctf_native_head or (0.0, 0.0, 0.0)
        _ctf_native_lines.append(
            "T {} {:.6f} {:.6f} {:.6f} {:.6f} {:.6f} {:.6f} {:.6f} {:.6f} {:.6f} {:.3f} {:.3f} {:.3f} {:.3f} {} {} {:.6f} {:.6f} {:.6f} {} {} {}\n".format(
                _ctf_native_key,
                _ctf_native_pos[0], _ctf_native_pos[1], _ctf_native_pos[2],
                _ctf_native_low[0], _ctf_native_low[1], _ctf_native_low[2],
                _ctf_native_high[0], _ctf_native_high[1], _ctf_native_high[2],
                _ctf_native_hp, _ctf_native_maxhp,
                _ctf_native_armor, _ctf_native_maxarmor, _ctf_native_dead,
                _ctf_native_has_head,
                _ctf_native_head[0], _ctf_native_head[1], _ctf_native_head[2],
                int(_ctf_native_is_visible),
                int(_ctf_native_is_robot),
                _ctf_native_relation,
            )
        )
    _ctf_native_lines.append(
        "W {} {:.6f} {:.6f}\n".format(
            _ctf_native_weapon_item_id,
            _ctf_native_projectile_speed,
            _ctf_native_projectile_gravity,
        )
    )
    _ctf_native_lines.append(
        "C {} {} {}\n".format(
            _ctf_native_detected_players,
            _ctf_native_detected_robots,
            _ctf_native_culled_targets,
        )
    )
    _ctf_native_lines.append("S {}\n".format(int(bool(state.get("exporter_ready", False)))))

    _ctf_native_local_temp_path = "{}.{}.{}.{}.tmp".format(
        _ctf_native_snapshot_path,
        _ctf_native_os.getpid(),
        state.get("tick", 0),
        int(_ctf_native_time.time() * 1000000),
    )
    with open(_ctf_native_local_temp_path, "w", encoding="ascii") as _ctf_native_handle:
        _ctf_native_handle.writelines(_ctf_native_lines)
    for _ctf_native_attempt in range(4):
        try:
            _ctf_native_os.replace(_ctf_native_local_temp_path, _ctf_native_snapshot_path)
            state["last_count"] = len(_ctf_native_rows)
            state["weapon_item_id"] = _ctf_native_weapon_item_id
            state["projectile_speed"] = _ctf_native_projectile_speed
            state["projectile_gravity"] = _ctf_native_projectile_gravity
            state["visible_targets"] = _ctf_native_visible_count
            state["culled_targets"] = _ctf_native_culled_targets
            state["detected_players"] = _ctf_native_detected_players
            state["detected_robots"] = _ctf_native_detected_robots
            return
        except PermissionError:
            # Readers use shared handles; retry around short external reads.
            _ctf_native_time.sleep(0.0015 * (_ctf_native_attempt + 1))
    try:
        _ctf_native_os.remove(_ctf_native_local_temp_path)
    except Exception:
        pass
    state["dropped_snapshots"] = state.get("dropped_snapshots", 0) + 1


def _ctf_native_tick(*_ctf_native_args, **_ctf_native_kwargs):
    _ctf_native_state = getattr(_ctf_native_builtins, _ctf_native_state_name, None)
    if not isinstance(_ctf_native_state, dict):
        return
    _ctf_native_now = _ctf_native_time.time()
    if _ctf_native_now < _ctf_native_state.get("next_snapshot_time", 0.0):
        return
    _ctf_native_state["next_snapshot_time"] = _ctf_native_now + _ctf_native_snapshot_interval
    try:
        _ctf_native_state["tick"] += 1
        _ctf_native_write_snapshot(_ctf_native_state)
        if _ctf_native_state["tick"] == 1 or _ctf_native_state["tick"] % 240 == 0:
            _ctf_native_log(
                "snapshot tick={} targets={} players={} bots={} culled={} range={:.0f} native_aim={} trigger={} external={} seen={} miss={} applied={} lock={} apply_frame_ok={} source_players={} source_robots={} weapon={} velocity={:.3f} posture_fallback={} skeleton_miss={}".format(
                    _ctf_native_state["tick"],
                    _ctf_native_state.get("last_count", 0),
                    _ctf_native_state.get("detected_players", 0),
                    _ctf_native_state.get("detected_robots", 0),
                    _ctf_native_state.get("culled_targets", 0),
                    _ctf_native_state.get("max_target_distance", _ctf_native_default_max_distance),
                    int(bool(_ctf_native_state.get("native_aim_enabled", True))),
                    _ctf_native_state.get("native_aim_trigger_down", 0),
                    _ctf_native_state.get("native_aim_external_down", 0),
                    _ctf_native_state.get("native_aim_trigger_seen", 0),
                    _ctf_native_state.get("native_aim_candidate_miss", 0),
                    _ctf_native_state.get("native_aim_applied", 0),
                    _ctf_native_state.get("native_aim_lock_key", None),
                    int(bool(_ctf_native_state.get("native_apply_frame_ok", False))),
                    _ctf_native_state.get("last_player_targets", 0),
                    _ctf_native_state.get("last_robot_targets", 0),
                    _ctf_native_state.get("weapon_item_id", 0),
                    _ctf_native_state.get("projectile_speed", 0.0),
                    _ctf_native_state.get("visibility_posture_fallback_count", 0),
                    _ctf_native_state.get("visibility_skeleton_miss_count", 0),
                )
            )
    except Exception:
        _ctf_native_log("TICK_EXC\n" + _ctf_native_traceback.format_exc())


def _ctf_native_install():
    _ctf_native_stop_legacy_timer()
    _ctf_native_old = getattr(_ctf_native_builtins, _ctf_native_state_name, None)
    if isinstance(_ctf_native_old, dict):
        _ctf_native_call(_ctf_native_old.get("timer_owner"), "cancel_timer", _ctf_native_old.get("timer_id"))

    _ctf_native_state = {
        "tick": 0,
        "timer_id": None,
        "timer_owner": None,
        "last_count": 0,
        "last_player_targets": 0,
        "last_robot_targets": 0,
        "weapon_item_id": 0,
        "projectile_speed": 0.0,
        "projectile_gravity": 0.0,
        "exporter_ready": False,
        "local_key": None,
        "head_models": {},
        "aim_bone_models": {},
        "physics_space": None,
        "visibility_cache": {},
        "visible_targets": 0,
        "visibility_posture_fallback_count": 0,
        "visibility_skeleton_miss_count": 0,
        "detected_players": 0,
        "detected_robots": 0,
        "max_target_distance": _ctf_native_default_max_distance,
        "native_aim_enabled": False,
        "native_aim_applied": 0,
        "native_aim_trigger_down": 0,
        "native_aim_external_down": 0,
        "native_aim_trigger_seen": 0,
        "native_aim_candidate_miss": 0,
        "native_aim_lock_key": None,
        "aim_fov_px": 0.0,
        "visible_only": True,
        "native_apply_frame_ok": False,
        "native_apply_frame_error": "",
        "next_config_refresh": 0.0,
        "next_snapshot_time": 0.0,
        "culled_targets": 0,
    }
    setattr(_ctf_native_builtins, _ctf_native_state_name, _ctf_native_state)
    _ctf_native_tick()
    _ctf_native_players, _ctf_native_robots = _ctf_native_entities()
    _ctf_native_owner = _ctf_native_timer_owner(_ctf_native_players, _ctf_native_robots)
    if _ctf_native_owner is None or not hasattr(_ctf_native_owner, "add_repeat_timer"):
        _ctf_native_log("INSTALL_FAILED no timer owner")
        return
    _ctf_native_state["timer_owner"] = _ctf_native_owner
    _ctf_native_state["timer_id"] = _ctf_native_owner.add_repeat_timer(1.0 / 120.0, _ctf_native_tick)
    _ctf_native_state["exporter_ready"] = True
    _ctf_native_write_snapshot(_ctf_native_state)
    _ctf_native_log(
        "INSTALL_OK hz=120 timer_id={!r} apply_frame_ok={} apply_frame_error={!r}".format(
            _ctf_native_state["timer_id"],
            _ctf_native_state.get("native_apply_frame_ok", False),
            _ctf_native_state.get("native_apply_frame_error", ""),
        )
    )


try:
    _ctf_native_install()
except Exception:
    _ctf_native_log("INSTALL_EXC\n" + _ctf_native_traceback.format_exc())
